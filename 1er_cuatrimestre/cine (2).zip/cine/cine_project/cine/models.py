# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Alquiler(models.Model):
    fecha_inicial = models.DateTimeField(blank=True, null=True)
    fecha_vencimiento = models.DateTimeField(blank=True, null=True)
    precio = models.CharField(max_length=60, blank=True, null=True)
    id_peli = models.ForeignKey('Pelicula', models.DO_NOTHING, db_column='id_peli', blank=True, null=True)
    id_usuario = models.ForeignKey('Usuario', models.DO_NOTHING, db_column='id_usuario', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'alquiler'


class Entrada(models.Model):
    orden = models.ForeignKey('OrdenCompra', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'entrada'


class Funcion(models.Model):
    tipo_funcion = models.CharField(max_length=45, blank=True, null=True)
    restricciones = models.CharField(max_length=45, blank=True, null=True)
    programacion = models.ForeignKey('Programacion', models.DO_NOTHING, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'funcion'


class Genero(models.Model):
    nombre = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'genero'


class OrdenCompra(models.Model):
    precio = models.CharField(max_length=80, blank=True, null=True)
    peli = models.ForeignKey('Pelicula', models.DO_NOTHING)
    usuario = models.ForeignKey('Usuario', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'orden_compra'


class Pelicula(models.Model):
    nombre = models.CharField(max_length=45, blank=True, null=True)
    clasificacion = models.CharField(max_length=45, blank=True, null=True)
    sala = models.ForeignKey('Sala', models.DO_NOTHING, blank=True, null=True)
    genero = models.ForeignKey(Genero, models.DO_NOTHING, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'pelicula'


class Programacion(models.Model):
    tipo_funcion = models.CharField(max_length=45, blank=True, null=True)
    restricciones = models.CharField(max_length=45, blank=True, null=True)
    programacion_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'programacion'


class Sala(models.Model):
    tipo_sala = models.CharField(max_length=45, blank=True, null=True)
    butaca = models.CharField(max_length=45, blank=True, null=True)
    funcion = models.ForeignKey(Funcion, models.DO_NOTHING, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sala'


class Usuario(models.Model):
    nombre = models.CharField(unique=True, max_length=60)
    correo = models.CharField(unique=True, max_length=80)
    sexo = models.CharField(max_length=20)
    telefono = models.CharField(unique=True, max_length=50)
    contraseña = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'usuario'

class Tarjetas(models.Model):
    id_tarjetas = models.AutoField(primary_key=True)
    num_card = models.CharField(max_length=16)
    fecha_vencimiento = models.DateTimeField()
    cod_seguridad = models.CharField(max_length=3, blank=True, null=True)
    id_usuarios = models.ForeignKey('Usuario', models.DO_NOTHING, db_column='id_usuarios')

    class Meta:
        managed = False
        db_table = 'tarjetas'
        