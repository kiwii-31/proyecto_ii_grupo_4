from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('bienvenido/', views.bienvenida_view, name='bienvenido'),
    path('peliculas/', views.lista_peliculas, name='peliculas'),
    path('pelicula/<int:peli_id>/comprar/', views.comprar_entrada, name='comprar_entrada'),
    path('pelicula/<int:peli_id>/alquilar/', views.alquilar_pelicula, name='alquilar_pelicula'),
    path('index/', views.index, name='index'),
    path('cartelera/', views.cartelera, name='cartelera'),
    path('contacto/', views.contacto, name='contacto'),
    path('perfil/', views.perfil, name='perfil'),
    path('nosotros/', views.nosotros, name='nosotros'),

]
