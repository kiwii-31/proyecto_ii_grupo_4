from django.shortcuts import render, redirect
from .models import Usuario
from .models import Pelicula
# Estos dos son para la compra de entradas del cine
from .models import OrdenCompra, Pelicula
from django.contrib.auth.decorators import login_required
from .models import Pelicula, Usuario, OrdenCompra, Tarjetas
#para alquilar una pelicula
from datetime import datetime, timedelta
from .models import Alquiler, Pelicula, Usuario
#tarjetas
from .models import Tarjetas
from datetime import datetime
#Sirve para buscar un objeto por ID. Si no lo encuentra, muestra error 404 automáticamente.
from django.shortcuts import render, get_object_or_404, redirect
def login_view(request):
    if request.method == 'POST':
        correo = request.POST['correo']
        contraseña = request.POST['contraseña']

        try:
            usuario = Usuario.objects.get(correo=correo, contraseña=contraseña)
            
            request.session['usuario_id'] = usuario.id

            return redirect('index')

        except Usuario.DoesNotExist:
            return render(request, 'login.html', {'error': 'Credenciales incorrectas'})

    return render(request, 'login.html')

# Esto es para retonar en resumen no guarda el login (return render(request, 'bienvenido.html', {'usuario': usuario}))


def register_view(request):
    if request.method == 'POST':
        nombre = request.POST['nombre']
        correo = request.POST['correo']
        sexo = request.POST['sexo']
        telefono = request.POST['telefono']
        contraseña = request.POST['contraseña']
        confirmar = request.POST['confirmar_contraseña'] 
        
        if contraseña != confirmar:
            return render(request, 'register.html', {'error': 'Las contraseñas no coinciden'})
        
        try:
            Usuario.objects.create(
                nombre=nombre,
                correo=correo,
                sexo=sexo,
                telefono=telefono,
                contraseña=contraseña 
            )
            return redirect('login')
        except Exception as e:
            return render(request, 'register.html', {'error': f'Error al registrar: {e}'})
    
    return render(request, 'register.html')

def home_view(request):
    return render(request, 'home.html')

def bienvenida_view(request): 
    peliculas = Pelicula.objects.all()
    return render(request, 'Bienvenido.html', {'peliculas': peliculas})


# esto es para la vista de una orden de compra en nuestro cine  

def comprar_entrada(request, peli_id):
    if 'usuario_id' not in request.session:
        return redirect('login')

    usuario_id = request.session['usuario_id']
    usuario = get_object_or_404(Usuario, id=usuario_id)
    pelicula = get_object_or_404(Pelicula, id=peli_id)
    PRECIO_ENTRADA = 1800

    if request.method == 'POST':
        num_card = request.POST.get('num_card')
        metodo = request.POST.get('metodo_pago')

        tarjeta, creada = Tarjetas.objects.get_or_create(
            num_card=num_card,
            id_usuarios=usuario,
            defaults={
                'fecha_vencimiento': datetime(2025, 12, 31), #otro ejemplo de fecha de vencimiento
                'cod_seguridad': '123'                       #es un ejemplo alta paja hacer que el usuario ingrese la tarjeta porque si 
                                                             #quiero que el usuario ingrese la tarjeta, fecha de vencimiento y el código de seguridad es mucho texto
            }
        )

        OrdenCompra.objects.create(
            precio=PRECIO_ENTRADA,
            peli=pelicula,
            usuario=usuario
        )

        return render(request, 'compra_exitosa.html', {
            'pelicula': pelicula,
            'precio': PRECIO_ENTRADA,
            'metodo': metodo,
            'tarjeta': tarjeta
        })

    return render(request, 'comprar_entrada.html', {
        'pelicula': pelicula,
        'precio': PRECIO_ENTRADA
    })
#
def lista_peliculas(request):
    peliculas = Pelicula.objects.all()
    return render(request, 'lista_peliculas.html', {'peliculas': peliculas})

def lista_peliculas(request):
    peliculas = Pelicula.objects.all()
    return render(request, 'lista_peliculas.html', {'peliculas': peliculas})

def comprar_entrada(request, peli_id):
    if 'usuario_id' not in request.session:
        return redirect('login')

    usuario_id = request.session['usuario_id']
    usuario = get_object_or_404(Usuario, id=usuario_id)
    pelicula = get_object_or_404(Pelicula, id=peli_id)
    PRECIO_ENTRADA = 1800

    if request.method == 'POST':
        num_card = request.POST.get('num_card')
        metodo = request.POST.get('metodo_pago')

        tarjeta, creada = Tarjetas.objects.get_or_create(
            num_card=num_card,
            id_usuarios=usuario,
            defaults={
                'fecha_vencimiento': datetime(2025, 12, 31),
                'cod_seguridad': '123'
            }
        )

        OrdenCompra.objects.create(
            precio=PRECIO_ENTRADA,
            peli=pelicula,
            usuario=usuario
        )

        return render(request, 'compra_exitosa.html', {
            'pelicula': pelicula,
            'precio': PRECIO_ENTRADA,
            'metodo': metodo,
            'tarjeta': tarjeta
        })

    return render(request, 'comprar_entrada.html', {
        'pelicula': pelicula,
        'precio': PRECIO_ENTRADA
    })
def alquilar_pelicula(request, peli_id):
    if 'usuario_id' not in request.session:
        return redirect('login')

    usuario_id = request.session['usuario_id']
    usuario = get_object_or_404(Usuario, id=usuario_id)
    pelicula = get_object_or_404(Pelicula, id=peli_id)
    PRECIO_ALQUILER = 1000

    if request.method == 'POST':
        num_card = request.POST.get('num_card')

        tarjeta, creada = Tarjetas.objects.get_or_create(
            num_card=num_card,
            id_usuarios=usuario,
            defaults={
                'fecha_vencimiento': datetime(2025, 12, 31),
                'cod_seguridad': '123'
            }
        )

        hoy = datetime.now()
        vencimiento = hoy + timedelta(days=3)

        Alquiler.objects.create(
            fecha_inicial=hoy,
            fecha_vencimiento=vencimiento,
            precio=PRECIO_ALQUILER,
            id_peli=pelicula,
            id_usuario=usuario
        )

        return render(request, 'alquiler_exitoso.html', {
            'pelicula': pelicula,
            'fecha_vencimiento': vencimiento,
            'precio': PRECIO_ALQUILER,
            'tarjeta': tarjeta
        })

    return render(request, 'alquilar_entrada.html', {
        'pelicula': pelicula,
        'precio': PRECIO_ALQUILER
    })

def index(request):
    return render(request, 'index.html')

# def cartelera(request):
#     peliculas = Pelicula.objects.all()
#     return render(request, 'cartelera.html', {'peliculas': peliculas})

def cartelera(request):
    query = request.GET.get('q')  # texto ingresado en el buscador
    if query:
        peliculas = Pelicula.objects.filter(nombre__icontains=query)
    else:
        peliculas = Pelicula.objects.all()
    return render(request, 'cartelera.html', {'peliculas': peliculas, 'query': query})


def bienvenida_view(request): 
    peliculas = Pelicula.objects.all()
    return render(request, 'Bienvenido.html', {'peliculas': peliculas})

def contacto(request):
    return render(request, 'contacto.html')

def perfil(request):
    return render(request, 'perfil.html')

def nosotros(request):
    return render(request, 'nosotros.html')

