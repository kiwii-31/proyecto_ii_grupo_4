"""esto es para el admin de la aplicacion cine y no tener que escribir dentro de python manage.py shell mas facil y practico creo"""
from django.contrib import admin 
from .models import Pelicula
from .models import Pelicula, Sala, Genero
"""para agregar peliculas por ahora por parte del admin"""
admin.site.register(Pelicula)
#para que el adminn elija  la sala y el genero de la pelicula
admin.site.register(Sala)
admin.site.register(Genero)

"""Explicacion del admin anterior mente al hacer python manage.py migrate
se crea una base de datos por defecto de django lo cual al princio me molestaba pero luego me di cuenta que era muy util para el admin de la aplicacion cine
y no tener que escribir dentro de python manage.py shell mas facil y practico por eso en models.py coloque managed = False haciendo referencia a que no quiero que django maneje la base de datos por defecto de django sino la que yo cree en el admin de la aplicacion cine
y asi poder agregar peliculas por ahora por parte del admin y no tener que escribir dentro de python"""